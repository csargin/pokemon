
#colors
BLACK = (0,0,0)
WHITE = (255,255,255)
RED = (255,0,0)
GREEN = (0,255,0)
BLUE = (0,0,255)
YELLOW = (255,255,0)

SCALE = 32 # Scale factor for the game
FPS = 50 # Frames per second for the game

SCEEN_WIDTH = 640 # Width of the game screen
SCEEN_HEIGHT = 480 # Height of the game 

PLAYER_IMAGE_PATH = "pokemon/imgs/player.png" # Path to the player image
MAP_PATH = "pokemon/maps/" # Path to the maps folder