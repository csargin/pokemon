
#colors
BLACK = (0,0,0)
WHITE = (255,255,255)
RED = (255,0,0)
GREEN = (0,255,0)
BLUE = (0,0,255)
YELLOW = (255,255,0)

SCALE = 10 # Scale factor for the game
FPS = 50 # Frames per second for the game