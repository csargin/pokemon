import config
import pygame
import math

class Map:
    def __init__(self, screen):
        self.screen = screen
        self.map_array = []
        self.camera = [0,0]

    def load(self, file_name):
        with open(config.MAP_PATH + file_name + ".txt" , "r") as map_file:
            for line in map_file:
                # Process the line to load the map
                tiles = []
                for i in range(0, len(line),2):
                    print(line.strip())
                    tiles.append(line[i])
                self.map_array.append(tiles)
        print(self.map_array)

    def render(self, screen, player, objects):
        # Render the map
        self.determine_camera(player)

        y_pos = 0
        for line in self.map_array:
            x_pos = 0
            for tile in line:
                image = map_tile_image[tile]
                rect = pygame.Rect(x_pos * config.SCALE - (self.camera[0] * config.SCALE), y_pos * config.SCALE - (self.camera[1] * config.SCALE), config.SCALE, config.SCALE)
                screen.blit(image, rect)   
                x_pos += 1
            y_pos += 1

        # Draw the objects on the map
        for object in objects:
            object.render(self.screen, self.camera)  

    def determine_camera(self, player):
        max_y_position = len(self.map_array) - config.SCREEN_HEIGHT / config.SCALE
        max_x_position = len(self.map_array[0]) - config.SCREEN_WIDTH / config.SCALE
        y_position = player.position[1] - math.ceil(round(config.SCREEN_HEIGHT / config.SCALE / 2))
        x_position = player.position[0] - math.ceil(round(config.SCREEN_WIDTH / config.SCALE / 2))

        if y_position <=max_y_position and y_position >= 0:
            self.camera[1] = y_position
        elif y_position < 0:
            self.camera[1] = 0
        elif y_position > max_y_position:
            self.camera[1] = max_y_position


        if x_position <=max_x_position and x_position >= 0:
            self.camera[0] = x_position
        elif x_position < 0:
            self.camera[0] = 0
        elif x_position > max_x_position:
            self.camera[0] = max_x_position

        return [self.camera[0], self.camera[1]]
    
map_tile_image = {
            config.MAP_TILE_GRASS: pygame.transform.scale(pygame.image.load(config.MAP_PATH + "grass1.png"), (config.SCALE, config.SCALE)),
            config.MAP_TILE_WATER: pygame.transform.scale(pygame.image.load(config.MAP_PATH + "water.png"), (config.SCALE, config.SCALE)),
            config.MAP_TILE_ROAD: pygame.transform.scale(pygame.image.load(config.MAP_PATH + "road.png"), (config.SCALE, config.SCALE)),
       
        }
