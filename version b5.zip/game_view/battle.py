import config
import pygame
import math
from game_state import GameState

class Battle:
    def __init__(self, screen, monster, player):
        self.screen = screen
        self.monster = monster
        self.player = player

    def load(self):
        pass

    def render(self):
        # Render the battle screen
        self.screen.fill(config.WHITE)
        rect = pygame.Rect(1, 1, 2, 2)
        self.screen.blit(self.monster.image, rect)

        self.screen.blit(self.player.image, (320,32))

        font = pygame.font.Font(None, 24)
        img = font.render("Health : " + str(self.monster.health) + " Attack : " + str(self.monster.attack) + " Defense : " + str(self.monster.defense) , True, config.BLACK)
        self.screen.blit(img, (20, 120))

        img = font.render("Press enter to attack", True, config.BLACK)


    def update(self):
        # Handle events
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                print("Game ended")
                pygame.quit()
                exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    print("Game ended")
                    pygame.quit()
                    exit()
                if event.key == pygame.K_RETURN:
                    print("Attack pressed")
                    self.monster.health -= self.player.attack
                    
                    
            



   
    

