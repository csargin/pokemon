
#colors
BLACK = (0,0,0)
WHITE = (255,255,255)
RED = (255,0,0)
GREEN = (0,255,0)
BLUE = (0,0,255)
YELLOW = (255,255,0)

SCALE = 32 # Scale factor for the game
FPS = 50 # Frames per second for the game

SCREEN_WIDTH = 640 # Width of the game screen
SCREEN_HEIGHT = 480 # Height of the game 

PLAYER_IMAGE_PATH = "pokemon/imgs/player.png" # Path to the player image
MAP_PATH = "pokemon/maps/" # Path to the maps folder
MENU_IMAGE_PATH = "pokemon/imgs/menu.png" # Path to the menu image
MONSTER_PATH = "pokemon/imgs/monsters/" # Path to the monster folder

MAP_TILE_WATER = "W" # Water tile
MAP_TILE_GRASS = "G" # Grass tile
MAP_TILE_ROAD = "R" # Road tile

GRASS_TYPE_START = 1 # GRASS_TYPE_START 
GRASS_TYPE_END = 5 # GRASS_TYPE_END

WATER_TYPE_START = 1 # WATER_TYPE_START 
WATER_TYPE_END = 3 # WATER_TYPE_END