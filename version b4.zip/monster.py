import pygame
import config

class Monster:
    """A class representing monsters in the game."""
    def __init__(self, monster_type):
        print("Monster created")
        self.type = monster_type
        self.health = 10
        self.attack = 2
        self.defense = 1
       
       
