from monster import Monster

class MonsterFactory:
    def __init__(self):
        self.count = 0
 
    def create_monster(self, monster_type):
        """Create a new monster of the specified type."""
        
        monster = Monster(monster_type)
        self.count += 1
        return monster